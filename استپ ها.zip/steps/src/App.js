import { useReducer } from "react";
import "./App.css";

const initialState = {
  step: 1,
  maxStep: 4,
};

function reducer(state, action) {
  switch (action.type) {
    case "next":
      return { ...state, step: state.step + 1 };
    case "prev":
      return { ...state, step: state.step - 1 };
    default:
      throw new Error();
  }
}

function App() {
  const [state, dispatch] = useReducer(reducer, initialState);

  return (
    <div className="container">
      <div className="pages">
        {[...Array(state.maxStep)].map((_, i) => (
          <>
            <div
              style={{
                backgroundColor:
                  state.step > i + 1 ? "rgb(70, 92, 216)" : "gray",
              }}
            >
              {i + 1}
            </div>
            <span></span>
          </>
        ))}
      </div>
      <div className="btns">
        <button
          data-testid="prevBtn"
          className="prevBtn"
          onClick={() => dispatch({ type: "prev" })}
          disabled={state.step === 1}
        >
          Prev
        </button>
        <button
          data-testid="nextBtn"
          onClick={() => dispatch({ type: "next" })}
          disabled={state.step === state.maxStep}
        >
          Next
        </button>
      </div>
    </div>
  );
}

export default App;
