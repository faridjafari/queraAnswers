class Post {
  constructor(id, title, body) {
    this.id = id;
    this.title = title;
    this.body = body;
  }
}

async function fetchPosts() {
  try {
    const response = await fetch("http://localhost:3000/posts");
    const postsData = await response.json();
    return postsData.map(post => new Post(post.id, post.title, post.body));
  } catch (error) {
    console.error("Error fetching posts:", error);
  }
}

function createPostListItem(post) {
  const li = document.createElement("li");
  const h3 = document.createElement("h3");
  const p = document.createElement("p");
  const em = document.createElement("em");

  h3.textContent = post.title;
  p.textContent = post.body;
  em.textContent = `شماره ${post.id}`;

  li.appendChild(h3);
  li.appendChild(p);
  li.appendChild(em);

  return li;
}

async function displayPosts() {
  const posts = await fetchPosts();
  const postList = document.getElementById("post-list");

  posts.forEach(post => {
    const listItem = createPostListItem(post);
    postList.appendChild(listItem);
  });
}

displayPosts();
